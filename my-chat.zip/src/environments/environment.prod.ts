export const environment = {
  production: true,
  firebase: {
   
      }
};
